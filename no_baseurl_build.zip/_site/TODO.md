# KGA Website TODO

## Comments to Address

### 1. Team Page Layout
- **Issue**: Currently team entries are displayed vertically, requiring scrolling
- **Goal**: Display team entries horizontally 
- **Options to explore**:
  - Small blurb with "click here for more" link
  - Headshots + name + title, with click for full bio
- **Note**: May require theme customization

### 2. Mailing List/Email Collection
- **Goal**: Add "join our mailing list" or "stay informed" section
- **Purpose**: Collect visitor email addresses
- **Backend considerations**: May need email notification system for manual processing

### 3. Blog Section Rename
- **Current**: "Blog" section
- **Proposed**: "The KGA Bulletin" or similar
- **Rationale**: Indicate news, press releases, and blog posts without high maintenance burden

### 4. Footer Contact Information
- **Current**: Green bar with "KGA 2025 copyright"
- **Goal**: Add address and phone number to footer on all pages

### 5. LinkedIn Integration
- **Goal**: Add LinkedIn button/link
- **Placement options**: Throughout site or just in "contact us" section

### 6. NJBIZ Badge Placement
- **Current**: "NJBIZ Reader Rankings" badge on clients page
- **Issue**: Seems out of place
- **Goal**: Find better placement for the badge